<?php
// ************************************
// This file is part of a package from:
// www.freecontactform.com
// See license for details
// ************************************

require dirname(__FILE__).'/'.'fcf.config.php';
require dirname(__FILE__).'/'.'process.php';